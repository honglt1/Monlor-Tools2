uci set monlor.tinyproxy=config
uci set monlor.tinyproxy.version=1.0
uci set monlor.tinyproxy.enable=0
