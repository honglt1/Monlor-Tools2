uci set monlor.vsftpd=config
uci set monlor.vsftpd.version=1.0
uci set monlor.vsftpd.enable=0
