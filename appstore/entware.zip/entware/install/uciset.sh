uci set monlor.entware=config
uci set monlor.entware.version=1.0
uci set monlor.entware.enable=0
