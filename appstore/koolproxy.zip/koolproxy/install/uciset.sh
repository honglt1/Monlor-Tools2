uci set monlor.koolproxy=config
uci set monlor.koolproxy.version=1.0
uci set monlor.koolproxy.enable=0
