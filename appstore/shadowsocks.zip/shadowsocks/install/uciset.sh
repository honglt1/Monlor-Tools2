uci set monlor.shadowsocks=config
uci set monlor.shadowsocks.version=1.0
uci set monlor.shadowsocks.enable=0
