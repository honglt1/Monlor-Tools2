uci set monlor.webshell=config
uci set monlor.webshell.version=1.0
uci set monlor.webshell.enable=0
