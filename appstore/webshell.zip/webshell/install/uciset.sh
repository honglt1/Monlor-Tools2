uci set monlor.webshell=config
uci set monlor.webshell.enable=0
