uci set monlor.aria2=config
uci set monlor.aria2.enable=0
