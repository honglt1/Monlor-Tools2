uci set monlor.frpc=config
uci set monlor.frpc.enable=0
