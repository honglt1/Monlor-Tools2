uci set monlor.frpc=config
uci set monlor.frpc.version=1.0
uci set monlor.frpc.enable=0
