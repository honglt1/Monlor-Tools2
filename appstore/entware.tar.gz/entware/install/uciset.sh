uci set monlor.entware=config
uci set monlor.entware.enable=0
