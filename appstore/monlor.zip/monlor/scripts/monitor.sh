#!/bin/ash
#copyright by monlor
source base.sh

$userdisk/.monlor.conf
uci commit monlor
#监控运行状态

