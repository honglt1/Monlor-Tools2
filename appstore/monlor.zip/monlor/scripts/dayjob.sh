#!/bin/ash
#copyright by monlor
source base.sh

#检查重启服务