uci set monlor.kms=config
uci set monlor.kms.version=1.0
uci set monlor.kms.enable=0
