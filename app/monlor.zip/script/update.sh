#!/bin/ash

MPATH=`uci get monlor.tools.mpath`
MURL="https://coding.net/u/monlor/p/Monlor-Tools/git/raw/master"
. $MPATH/script/mecho

uci set monlor.$1.enable=1
uci commit monlor
MEO -bla1t "Update ss files ... \c"
ping -4 baidu.com -c 4 -w 10 -q > /dev/null 2>&1
if [ $? -ne 0 ]; then
	MEO -red1 "Failed!(bad network)"
	exit
fi
curl -sLo /tmp/$1.zip $MURL/app/$1.zip 
curl -sLo /tmp/md5info $MURL/app/md5info 
[ $? -ne 0 ] && MEO -red1 "Failed!(download failed)"
[ "`cat /tmp/md5info | grep $1.zip | cut -d' ' -f4`" != "`md5sum /tmp/$1.zip | cut -d ' ' -f1`" ] && MEO -red1 "Failed!(verify failed)" && exit
unzip -o /tmp/$1.zip -d $MPATH > /dev/null 2>&1
chmod -R +x $MPATH
rm -rf /tmp/$1.zip /tmp/md5info
MEO -gre1 "Done!"
